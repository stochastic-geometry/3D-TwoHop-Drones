function [c1, c2, eta_LoS, eta_NLoS] = Compute_Param_LoS(Environment)
switch Environment
    case 'Suburban'
        alpha = 0.1;
        beta = 750;
        gamma = 8;
        eta_LoS = db2pow(0.1);
        eta_NLoS = db2pow(21);%db2pow(3.1);%
    case 'Urban'
        alpha = 0.3;
        beta = 500;
        gamma = 15;
        eta_LoS = db2pow(1);
        eta_NLoS = db2pow(20);%db2pow(4);%
    case 'DenseUrban'
        alpha = 0.5;
        beta = 300;
        gamma = 20;
        eta_LoS = db2pow(1.6);
        eta_NLoS = db2pow(23);%db2pow(4.6);%
    case 'HighriseUrban'
        alpha = 0.5;
        beta = 300;
        gamma = 50;
        eta_LoS = db2pow(2.3);
        eta_NLoS = db2pow(34);%db2pow(5.8);%
    otherwise % 'Urban'
        alpha = 0.3;
        beta = 500;
        gamma = 15;
        eta_LoS = db2pow(1);
        eta_NLoS = db2pow(20);%db2pow(4);%
end
aC = [9.34e-1, 1.97e-2, -1.24e-4, 2.73e-7; 2.30e-1, 2.44e-3, -3.34e-6, 0; -2.25e-3, 6.58e-6, 0, 0; 1.86e-5, 0, 0, 0].';
bC = [1.17e0, -5.79e-3, 1.73e-5, -2.00e-8; -7.56e-2, 1.81e-4, -2.02e-7, 0; 1.98e-3, -1.65e-6, 0, 0; -1.78e-5, 0, 0, 0].';
c1 = 0;
c2 = 0;
for j = 0 : 3
    for i = 0 : 3 - j
        c1 = c1 + aC(i + 1, j + 1) * (alpha * beta) ^ i * gamma ^ j;
        c2 = c2 + bC(i + 1, j + 1) * (alpha * beta) ^ i * gamma ^ j;
    end
end