%% Parameters
a = 1;
b = 4;
I = 2;
m = 2;
g = 1;
N = 1e5;
X_Naka = gamrnd(m, 1 / m, [N, 1]);
Y_Naka = gamrnd(m, 1 / m, [N, 1]);
T1_Naka = a * X_Naka ./ (b * Y_Naka + I);
T2_Naka = max(a * X_Naka, b * Y_Naka) ./ (min(a * X_Naka, b * Y_Naka) + I);
T3_Naka = b * Y_Naka ./ (a * X_Naka + I + g * (a * X_Naka + b * Y_Naka + I));

%% Analysis
tau = 0 : 0.01 : ceil(ceil(max(max([T1_Naka, T2_Naka, T3_Naka])) * 100) / 200);
len_tau = length(tau);
F_T1_Naka_Sim = zeros(length(tau), 1);
F_T1_Naka_Thr = zeros(length(tau), 1);
F_T2_Naka_Sim = zeros(length(tau), 1);
F_T2_Naka_Thr = zeros(length(tau), 1);
F_T3T1_Naka_Sim = zeros(length(tau), 1);
F_T3T1_Naka_Thr = zeros(length(tau), 1);
for ind_tau = 1 : len_tau
    F_T1_Naka_Sim(ind_tau) = sum(T1_Naka <= tau(ind_tau)) / N;
    A = 0;
    for i = 0 : m - 1
        for k = 0 : i
            A = A + nchoosek(k + m - 1, k) / factorial(i - k) * (a ^ m * (b * tau(ind_tau)) ^ k) / (a + b * tau(ind_tau)) ^ (m + k) * ((m * tau(ind_tau)) / a * I) ^ (i - k) * exp(-(m * tau(ind_tau)) / a * I);
        end
    end
    F_T1_Naka_Thr(ind_tau) = 1 - A;
    
    F_T2_Naka_Sim(ind_tau) = sum(T2_Naka <= tau(ind_tau)) / N;
    A = [0, 0, 0];
    if tau(ind_tau) < 1
        for i = 0 : m - 1
            A(1) = A(1) + nchoosek(i + m - 1, i) * gammainc((1 / a + 1 / b) * m * tau(ind_tau) / (1 - tau(ind_tau)) * I, m + i) * (a ^ m * b ^ i + a ^ i * b ^ m) / (a + b) ^ (m + i);
            for k = 0 : i
                A(2) = A(2) + nchoosek(k + m - 1, k) * gammainc((tau(ind_tau) / a + 1 / b) * m * tau(ind_tau) / (1 - tau(ind_tau)) * I, m + k) / factorial(i - k) * (a ^ m * (b * tau(ind_tau)) ^ k) / (a + b * tau(ind_tau)) ^ (m + k) * ((m * tau(ind_tau)) / a * I) ^ (i - k) * exp(-(m * tau(ind_tau)) / a * I);
                A(3) = A(3) + nchoosek(k + m - 1, k) * gammainc((tau(ind_tau) / b + 1 / a) * m * tau(ind_tau) / (1 - tau(ind_tau)) * I, m + k) / factorial(i - k) * (b ^ m * (a * tau(ind_tau)) ^ k) / (b + a * tau(ind_tau)) ^ (m + k) * ((m * tau(ind_tau)) / b * I) ^ (i - k) * exp(-(m * tau(ind_tau)) / b * I);
            end
        end
    else
        for i = 0 : m - 1
            A(1) = A(1) + nchoosek(i + m - 1, i) * (a ^ m * b ^ i + a ^ i * b ^ m) / (a + b) ^ (m + i);
            for k = 0 : i
                A(2) = A(2) + nchoosek(k + m - 1, k) / factorial(i - k) * (a ^ m * (b * tau(ind_tau)) ^ k) / (a + b * tau(ind_tau)) ^ (m + k) * ((m * tau(ind_tau)) / a * I) ^ (i - k) * exp(-(m * tau(ind_tau)) / a * I);
                A(3) = A(3) + nchoosek(k + m - 1, k) / factorial(i - k) * (b ^ m * (a * tau(ind_tau)) ^ k) / (b + a * tau(ind_tau)) ^ (m + k) * ((m * tau(ind_tau)) / b * I) ^ (i - k) * exp(-(m * tau(ind_tau)) / b * I);
            end
        end
    end
    F_T2_Naka_Thr(ind_tau) = A(1) - A(2) - A(3);
    
    F_T3T1_Naka_Sim(ind_tau) = sum((T1_Naka <= tau(ind_tau)) & (T3_Naka <= tau(ind_tau))) / N;
    A = [0, 0, 0];
    if tau(ind_tau) < 1 / (1 + g)
        for i = 0 : m - 1
            A(1) = A(1) + nchoosek(i + m - 1, i) * gammainc((1 / (a * (1 + g)) + 1 / b) * m * tau(ind_tau) * (1 + g) / (1 - tau(ind_tau) * (1 + g)) * I, m + i) * ((a * (1 + g)) ^ m * b ^ i + (a * (1 + g))^ i * b ^ m) / (a * (1 + g) + b) ^ (m + i);
            for k = 0 : i
                A(2) = A(2) + nchoosek(k + m - 1, k) * gammainc((tau(ind_tau) / a + 1 / b) * m * tau(ind_tau) * (1 + g) / (1 - tau(ind_tau) * (1 + g)) * I, m + k) / factorial(i - k) * (a ^ m * (b * tau(ind_tau)) ^ k) / (a + b * tau(ind_tau)) ^ (m + k) * ((m * tau(ind_tau)) / a * I) ^ (i - k) * exp(-(m * tau(ind_tau)) / a * I);
                A(3) = A(3) + nchoosek(k + m - 1, k) * gammainc((tau(ind_tau) / (b * (1 - tau(ind_tau) * g)) + 1 / (a * (1 + g))) * m * tau(ind_tau) * (1 + g) / (1 - tau(ind_tau) * (1 + g)) * I, m + k) / factorial(i - k) * ((b * (1 - tau(ind_tau) * g)) ^ m * (a * tau(ind_tau) * (1 + g)) ^ k) / (b * (1 - tau(ind_tau) * g) + a * tau(ind_tau) * (1 + g)) ^ (m + k) * ((m * tau(ind_tau) * (1 + g)) / (b * (1 - tau(ind_tau) * g)) * I) ^ (i - k) * exp(-(m * tau(ind_tau) * (1 + g)) / (b * (1 - tau(ind_tau) * g)) * I);
            end
        end
    elseif tau(ind_tau) < 1 / g
        for i = 0 : m - 1
            A(1) = A(1) + nchoosek(i + m - 1, i) * ((a * (1 + g)) ^ m * b ^ i + (a * (1 + g)) ^ i * b ^ m) / (a * (1 + g) + b) ^ (m + i);
            for k = 0 : i
                A(2) = A(2) + nchoosek(k + m - 1, k) / factorial(i - k) * (a ^ m * (b * tau(ind_tau)) ^ k) / (a + b * tau(ind_tau)) ^ (m + k) * ((m * tau(ind_tau)) / a * I) ^ (i - k) * exp(-(m * tau(ind_tau)) / a * I);
                A(3) = A(3) + nchoosek(k + m - 1, k) / factorial(i - k) * ((b * (1 - tau(ind_tau) * g)) ^ m * (a * tau(ind_tau) * (1 + g)) ^ k) / (b * (1 - tau(ind_tau) * g) + a * tau(ind_tau) * (1 + g)) ^ (m + k) * ((m * tau(ind_tau) * (1 + g)) / (b * (1 - tau(ind_tau) * g)) * I) ^ (i - k) * exp(-(m * tau(ind_tau) * (1 + g)) / (b * (1 - tau(ind_tau) * g)) * I);
            end
        end
    else
        A(1) = 1;
        for i = 0 : m - 1
            for k = 0 : i
                A(2) = A(2) + nchoosek(k + m - 1, k) / factorial(i - k) * (a ^ m * (b * tau(ind_tau)) ^ k) / (a + b * tau(ind_tau)) ^ (m + k) * ((m * tau(ind_tau)) / a * I) ^ (i - k) * exp(-(m * tau(ind_tau)) / a * I);
            end
        end
    end
    F_T3T1_Naka_Thr(ind_tau) = A(1) - A(2) - A(3);
end

%% Plots
tau_dec = [1 : 10 : round(len_tau / 10), round(len_tau / 10) + 20 : 30 : round(len_tau / 4), round(len_tau / 4) + 50 : 50 : len_tau];
figure(403)
hold on
grid on
box on
plot(tau, F_T1_Naka_Thr, 'LineWidth' , 2, 'LineStyle', '-')
plot(tau, F_T2_Naka_Thr, 'LineWidth' , 2, 'LineStyle', '--')
plot(tau, F_T3T1_Naka_Thr, 'LineWidth' , 2, 'LineStyle', ':')
plot(tau(tau_dec), F_T1_Naka_Sim(tau_dec), 'LineWidth' , 2, 'LineStyle', 'none', 'Marker', 'o', 'MarkerFaceColor', 'w', 'MarkerEdgeColor', 'k', 'MarkerSize', 6)
plot(tau(tau_dec), F_T2_Naka_Sim(tau_dec), 'LineWidth' , 2, 'LineStyle', 'none', 'Marker', 'o', 'MarkerFaceColor', 'w', 'MarkerEdgeColor', 'k', 'MarkerSize', 6)
plot(tau(tau_dec), F_T3T1_Naka_Sim(tau_dec), 'LineWidth' , 2, 'LineStyle', 'none', 'Marker', 'o', 'MarkerFaceColor', 'w', 'MarkerEdgeColor', 'k', 'MarkerSize', 6)
xlabel('$\tau$', 'Interpreter', 'latex', 'FontSize', 12)
ylabel('cdf', 'Interpreter', 'latex', 'FontSize', 12)
legend({'$F_{T_1}(\tau)$', '$F_{T_2}(\tau)$', '$F_{T_1T_3}(\tau, \tau)$', 'Simulation'}, 'Interpreter', 'latex', 'FontSize', 12, 'Location', 'southeast')
hold off