These codes generate Figs. 3-9 of [1].

Please cite [1] if you reuse any part of these codes.

[1] M. Banagar and H. S. Dhillon, “3D two-hop cellular networks with wireless backhauled UAVs: Modeling and fundamentals,” to appear in IEEE Transactions on Wireless Communications, available online: https://ieeexplore.ieee.org/document/9712177