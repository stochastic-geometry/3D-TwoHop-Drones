%% Parameters
a = 3;
b = 3;
I = 2;
m = 2;
N = 1e5;
X_Rayl = exprnd(1, [N, 1]);
Y_Rayl = exprnd(1, [N, 1]);
T2_Rayl = max(a * X_Rayl, b * Y_Rayl) ./ (min(a * X_Rayl, b * Y_Rayl) + I);
X_Naka = gamrnd(m, 1 / m, [N, 1]);
Y_Naka = gamrnd(m, 1 / m, [N, 1]);
T2_Naka = max(a * X_Naka, b * Y_Naka) ./ (min(a * X_Naka, b * Y_Naka) + I);

%% Analysis
tau = 0 : 0.01 : ceil(max(T2_Naka) * 100) / 100;
len_tau = length(tau);
F_T2_Rayl_Sim = zeros(length(tau), 1);
F_T2_Rayl_Thr = zeros(length(tau), 1);
F_T2_Naka_Sim = zeros(length(tau), 1);
F_T2_Naka_Thr = zeros(length(tau), 1);
for ind_tau = 1 : len_tau
    F_T2_Rayl_Sim(ind_tau) = sum(T2_Rayl <= tau(ind_tau)) / N;
    F_T2_Rayl_Thr(ind_tau) = 1 - a / (a + b * tau(ind_tau)) * exp(-tau(ind_tau) / a * I) - b / (b + a * tau(ind_tau)) * exp(-tau(ind_tau) / b * I) + (tau(ind_tau) < 1) * (a * b * (1 + tau(ind_tau)) * (1 - tau(ind_tau))) / ((a + b * tau(ind_tau)) * (b + a * tau(ind_tau))) * exp(-(1 / a + 1 / b) * tau(ind_tau) / (1 - tau(ind_tau)) * I);
    F_T2_Naka_Sim(ind_tau) = sum(T2_Naka <= tau(ind_tau)) / N;
    A = [0, 0, 0];
    if tau(ind_tau) < 1
        for i = 0 : m - 1
            A(1) = A(1) + nchoosek(i + m - 1, i) * gammainc((1 / a + 1 / b) * m * tau(ind_tau) / (1 - tau(ind_tau)) * I, m + i) * (a ^ m * b ^ i + a ^ i * b ^ m) / (a + b) ^ (m + i);
            for k = 0 : i
                A(2) = A(2) + nchoosek(k + m - 1, k) * gammainc((tau(ind_tau) / a + 1 / b) * m * tau(ind_tau) / (1 - tau(ind_tau)) * I, m + k) / factorial(i - k) * (a ^ m * (b * tau(ind_tau)) ^ k) / (a + b * tau(ind_tau)) ^ (m + k) * ((m * tau(ind_tau)) / a * I) ^ (i - k) * exp(-(m * tau(ind_tau)) / a * I);
                A(3) = A(3) + nchoosek(k + m - 1, k) * gammainc((tau(ind_tau) / b + 1 / a) * m * tau(ind_tau) / (1 - tau(ind_tau)) * I, m + k) / factorial(i - k) * (b ^ m * (a * tau(ind_tau)) ^ k) / (b + a * tau(ind_tau)) ^ (m + k) * ((m * tau(ind_tau)) / b * I) ^ (i - k) * exp(-(m * tau(ind_tau)) / b * I);
            end
        end
    else
        for i = 0 : m - 1
            A(1) = A(1) + nchoosek(i + m - 1, i) * (a ^ m * b ^ i + a ^ i * b ^ m) / (a + b) ^ (m + i);
            for k = 0 : i
                A(2) = A(2) + nchoosek(k + m - 1, k) / factorial(i - k) * (a ^ m * (b * tau(ind_tau)) ^ k) / (a + b * tau(ind_tau)) ^ (m + k) * ((m * tau(ind_tau)) / a * I) ^ (i - k) * exp(-(m * tau(ind_tau)) / a * I);
                A(3) = A(3) + nchoosek(k + m - 1, k) / factorial(i - k) * (b ^ m * (a * tau(ind_tau)) ^ k) / (b + a * tau(ind_tau)) ^ (m + k) * ((m * tau(ind_tau)) / b * I) ^ (i - k) * exp(-(m * tau(ind_tau)) / b * I);
            end
        end
    end
    F_T2_Naka_Thr(ind_tau) = A(1) - A(2) - A(3);
end

%% Plots
figure(402)
hold on
grid on
box on
plot(tau, F_T2_Rayl_Sim, 'k', 'LineWidth' , 2)
plot(tau, F_T2_Rayl_Thr, 'r', 'LineWidth' , 2, 'LineStyle', '--')
plot(tau, F_T2_Naka_Sim, 'b', 'LineWidth' , 2)
plot(tau, F_T2_Naka_Thr, 'g', 'LineWidth' , 2, 'LineStyle', '--')
xlabel('$\tau$', 'Interpreter', 'latex', 'FontSize', 12)
ylabel('CDF of $T_2$', 'Interpreter', 'latex', 'FontSize', 12)
legend({'Rayleigh Fading, Simulation', 'Rayleigh Fading, Theory', 'Nakagami Fading, Simulation', 'Nakagami Fading, Theory'}, 'Interpreter', 'latex', 'FontSize', 12, 'Location', 'southeast')
hold off
