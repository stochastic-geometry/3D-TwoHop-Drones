%% Parameters
datetime('now')
lambda_D = 1e-6;%1e-5;%
h_D_min = 100;%-1e4;%
h_D_max = 300;%1e4;%
r_diff = 5;%30;%
r_max = 250;%3000;%
r = h_D_min : r_diff : r_max;
theta = 0 : 0.05 : 1.1;%pi / 2;
len_r = length(r);
len_theta = length(theta);
theta_D_min = acos(h_D_min ./ r);
theta_D_max = acos(min(h_D_max ./ r, 1));
Environment = 'Suburban'; % Choose between 'Suburban', 'Urban', 'DenseUrban', and 'HighriseUrban'
[c1, c2, eta_LoS, eta_NLoS] = Compute_Param_LoS(Environment);
alpha_LoS = 2.5;
alpha_NLoS = 4;

%% Simulation
x_D_min = -1e4;
x_D_max = 1e4;
y_D_min = -1e4;
y_D_max = 1e4;
Num_D_Initial = lambda_D * (x_D_max - x_D_min) * (y_D_max - y_D_min) * (h_D_max - h_D_min);
Realizations = 1e5;
Closest_D_LoS = zeros(Realizations, 2);
Closest_D_NLoS = zeros(Realizations, 2);
A_N_vec = false(Realizations, 1);
tic
parfor i = 1 : Realizations
    Num_D = poissrnd(Num_D_Initial);
    Pos_D_x = unifrnd(x_D_min, x_D_max, [Num_D, 1]);
    Pos_D_y = unifrnd(y_D_min, y_D_max, [Num_D, 1]);
    Pos_D_z = unifrnd(h_D_min, h_D_max, [Num_D, 1]);
    Pos_D = [Pos_D_x, Pos_D_y, Pos_D_z];
    Pos_D_range = sqrt(sum(Pos_D .^ 2, 2));
    Pos_D_theta = acos(Pos_D_z ./ Pos_D_range);
    ProbLoS = ProbLoS_Sigmoid(Pos_D_theta, c1, c2);
    Pos_D_LoS_ind = rand(Num_D, 1) < ProbLoS;%0.5;
    Pos_D_NLoS_ind = ~Pos_D_LoS_ind;
    Pos_D_LoS = Pos_D(Pos_D_LoS_ind, :);
    Pos_D_NLoS = Pos_D(Pos_D_NLoS_ind, :);
    Pos_D_range_LoS = Pos_D_range(Pos_D_LoS_ind, :);
    Pos_D_range_NLoS = Pos_D_range(Pos_D_NLoS_ind, :);
    [r_tilde_D_LoS, ind_min_D_LoS] = min(Pos_D_range_LoS);
    [r_tilde_D_NLoS, ind_min_D_NLoS] = min(Pos_D_range_NLoS);
    theta_tilde_D_LoS = acos(Pos_D_LoS(ind_min_D_LoS, 3) / r_tilde_D_LoS);
    theta_tilde_D_NLoS = acos(Pos_D_NLoS(ind_min_D_NLoS, 3) / r_tilde_D_NLoS);
    A_N_vec(i) = r_tilde_D_NLoS ^ (-alpha_NLoS) * eta_NLoS ^ -1 >= r_tilde_D_LoS ^ (-alpha_LoS) * eta_LoS ^ -1;
    Closest_D_LoS(i, :) = [r_tilde_D_LoS, theta_tilde_D_LoS];
    Closest_D_NLoS(i, :) = [r_tilde_D_NLoS, theta_tilde_D_NLoS];
end
toc
Serving_D_LoS = repmat(~A_N_vec, 1, 2) .* Closest_D_LoS;
Serving_D_LoS(A_N_vec, :) = [];
Serving_D_NLoS = repmat(A_N_vec, 1, 2) .* Closest_D_NLoS;
Serving_D_NLoS(~A_N_vec, :) = [];
figure(406)
histogram2(Serving_D_LoS(:, 1), Serving_D_LoS(:, 2), 'Normalization', 'pdf')
hold on

%% Theory
r0 = (eta_NLoS / eta_LoS) ^ (1 / alpha_LoS) * h_D_min ^ (alpha_NLoS / alpha_LoS);
beta_LoS_int1 = @(r1) arrayfun(@(r1) beta_LoS_int1_fun(r1, h_D_min, h_D_max, c1, c2), r1);
beta_NLoS_int1 = @(r1) arrayfun(@(r1) beta_NLoS_int1_fun(r1, h_D_min, h_D_max, c1, c2), r1);
fun01 = @(r1, theta1) exp(-pi * lambda_D * (beta_LoS_int1(r1) + beta_NLoS_int1((eta_LoS / eta_NLoS) ^ (1 / alpha_NLoS) .* r1 .^ (alpha_LoS / alpha_NLoS)))) .* 2 .* pi .* lambda_D .* r1 .^ 2 .* sin(theta1) .* ProbLoS_Sigmoid(theta1, c1, c2);
fun02 = @(r1, theta1) exp(-pi * lambda_D * (beta_NLoS_int1(r1) + beta_LoS_int1((eta_NLoS / eta_LoS) ^ (1 / alpha_LoS) .* r1 .^ (alpha_NLoS / alpha_LoS)))) .* 2 .* pi .* lambda_D .* r1 .^ 2 .* sin(theta1) .* (1 - ProbLoS_Sigmoid(theta1, c1, c2));
fun1 = @(r1, theta1) arrayfun(@(r1, theta1) fun01(r1, theta1), r1, theta1);
fun2 = @(r1, theta1) arrayfun(@(r1, theta1) fun02(r1, theta1), r1, theta1);
A_L_Thr = integral2(fun1, r0, inf, @(r1) acos(min(h_D_max ./ r1, 1)), @(r1) acos(h_D_min ./ r1)) + 1 - exp(-pi * lambda_D * beta_LoS_int1_fun(r0, h_D_min, h_D_max, c1, c2));
A_N_Thr = integral2(fun2, h_D_min, inf, @(r1) acos(min(h_D_max ./ r1, 1)), @(r1) acos(h_D_min ./ r1));

r00 = max(h_D_min, (eta_LoS / eta_NLoS) ^ (1 / alpha_NLoS) * r .^ (alpha_LoS / alpha_NLoS));
thetaD_min00 = acos(h_D_min ./ r00);
beta_LoS = zeros(len_r, 1);
beta_NLoS = zeros(len_r, 1);
PDF_Serving_3D_Thr = zeros(len_r, len_theta);
parfor ind_r = 2 : len_r
    beta_LoS(ind_r) = 2 / 3 * integral(@(theta1) (min(h_D_max ^ 3, r(ind_r) ^ 3 * cos(theta1) .^ 3) - h_D_min ^ 3) .* sin(theta1) ./ cos(theta1) .^ 3 .* ProbLoS_Sigmoid(theta1, c1, c2), 0, theta_D_min(ind_r));
    beta_NLoS(ind_r) = 2 / 3 * integral(@(theta1) (min(h_D_max ^ 3, r00(ind_r) ^ 3 * cos(theta1) .^ 3) - h_D_min ^ 3) .* sin(theta1) ./ cos(theta1) .^ 3 .* (1 - ProbLoS_Sigmoid(theta1, c1, c2)), 0, thetaD_min00(ind_r));
    for ind_theta = 1 : len_theta
        if (theta(ind_theta) <= theta_D_min(ind_r)) && (theta(ind_theta) >= theta_D_max(ind_r))
            PDF_Serving_3D_Thr(ind_r, ind_theta) = 1 / A_L_Thr * 2 * pi * lambda_D * r(ind_r) ^ 2 * integral(@(theta1) sin(theta1) .* ProbLoS_Sigmoid(theta1, c1, c2), theta_D_max(ind_r), theta_D_min(ind_r)) * exp(-pi * lambda_D * (beta_LoS(ind_r) + beta_NLoS(ind_r))) * r(ind_r) / (min(h_D_max, r(ind_r)) - h_D_min) * sin(theta(ind_theta));
        end
    end
end
surf(repmat(r, length(theta), 1), repmat(theta.', 1, length(r)), PDF_Serving_3D_Thr.')
xlabel('Distance $r$ (m)', 'Interpreter', 'latex', 'FontSize', 12)
ylabel('Zenith Angle $\theta$ (rad)', 'Interpreter', 'latex', 'FontSize', 12)
zlabel('Joint pdf', 'Interpreter', 'latex', 'FontSize', 12)
box on
hold off
datetime('now')

function I = beta_LoS_int1_fun(r1, h_D_min, h_D_max, c1, c2)
g1 = @(theta1) (min(h_D_max ^ 3, r1 .^ 3 .* cos(theta1) .^ 3) - h_D_min ^ 3) .* sin(theta1) ./ cos(theta1) .^ 3 .* ProbLoS_Sigmoid(theta1, c1, c2);
I = 2 / 3 * integral(g1, 0, acos(h_D_min ./ r1));
end
function I = beta_NLoS_int1_fun(r1, h_D_min, h_D_max, c1, c2)
g1 = @(theta1) (min(h_D_max ^ 3, r1 .^ 3 .* cos(theta1) .^ 3) - h_D_min ^ 3) .* sin(theta1) ./ cos(theta1) .^ 3 .* (1 - ProbLoS_Sigmoid(theta1, c1, c2));
I = 2 / 3 * integral(g1, 0, acos(h_D_min ./ r1));
end