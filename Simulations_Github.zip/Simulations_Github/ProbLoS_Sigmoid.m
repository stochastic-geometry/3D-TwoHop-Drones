function p_LoS = ProbLoS_Sigmoid(theta_rad, c1, c2)
p_LoS = 1 ./ (1 + c1 * exp(-c2 * (90 - rad2deg(theta_rad) - c1)));