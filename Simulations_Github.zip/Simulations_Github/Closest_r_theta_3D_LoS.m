%% Parameters
lambda_D = 1e-7;%1e-5;%
h_D_min = 50;%-1e4;%
h_D_max = 300;%1e4;%
r_diff = 5;%30;%
r_max = 200;%3000;%
r = h_D_min : r_diff : r_max;
theta = 0 : 0.05 : pi / 2;
len_r = length(r);
len_theta = length(theta);
theta_D_min = acos(h_D_min ./ r);
theta_D_max = acos(min(h_D_max ./ r, 1));
Environment = 'Suburban'; % Choose between 'Suburban', 'Urban', 'DenseUrban', and 'HighriseUrban'
[c1, c2, ~, ~] = Compute_Param_LoS(Environment);

%% Simulation
x_D_min = -1e4;
x_D_max = 1e4;
y_D_min = -1e4;
y_D_max = 1e4;
Num_D_Initial = lambda_D * (x_D_max - x_D_min) * (y_D_max - y_D_min) * (h_D_max - h_D_min);
Realizations = 1e4;
Closest_D = zeros(Realizations, 2);
tic
parfor i = 1 : Realizations
    Num_D = poissrnd(Num_D_Initial);
    Pos_D_x = unifrnd(x_D_min, x_D_max, [Num_D, 1]);
    Pos_D_y = unifrnd(y_D_min, y_D_max, [Num_D, 1]);
    Pos_D_z = unifrnd(h_D_min, h_D_max, [Num_D, 1]);
    Pos_D = [Pos_D_x, Pos_D_y, Pos_D_z];
    Pos_D_range = sqrt(sum(Pos_D .^ 2, 2));
    Pos_D_theta = acos(Pos_D_z ./ Pos_D_range);
    ProbLoS = ProbLoS_Sigmoid(Pos_D_theta, c1, c2);
    Pos_D_LoS_ind = rand(Num_D, 1) < ProbLoS;%0.5;
    Pos_D_LoS = Pos_D(Pos_D_LoS_ind, :);
    Pos_D_range_LoS = Pos_D_range(Pos_D_LoS_ind, :);
    [r_tilde_D, ind_min_D] = min(Pos_D_range_LoS);
    theta_tilde_D = acos(Pos_D_LoS(ind_min_D, 3) / r_tilde_D);
    Closest_D(i, :) = [r_tilde_D, theta_tilde_D];
% % % %     figure(100)
% % % %     plot3(Pos_D(:, 1), Pos_D(:, 2), Pos_D(:, 3), 'b.')
% % % %     hold on
% % % %     plot3(Pos_D_LoS(:, 1), Pos_D_LoS(:, 2), Pos_D_LoS(:, 3), 'r.')
end
toc
CDF_Closest_3D_Sim = zeros(len_r, len_theta);
for ind_r = 1 : len_r
    for ind_theta = 1 : len_theta
        CDF_Closest_3D_Sim(ind_r, ind_theta) = sum((Closest_D(:, 1) <= r(ind_r)) & (Closest_D(:, 2) <= theta(ind_theta))) / Realizations;
    end
end
% % figure(405)
% % histogram2(Closest_D(:, 1), Closest_D(:, 2), 'Normalization', 'pdf')
% % hold on

%% Theory
beta_LoS = zeros(len_r, 1);
PDF_Closest_3D_Thr = zeros(len_r, len_theta);
CDF_Closest_3D_Thr = zeros(len_r, len_theta);
parfor ind_r = 2 : len_r
    disp(r(ind_r))
    tic
    beta_LoS(ind_r) = 2 / 3 * integral(@(theta1) (min(h_D_max ^ 3, r(ind_r) ^ 3 * cos(theta1) .^ 3) - h_D_min ^ 3) .* sin(theta1) ./ cos(theta1) .^ 3 .* ProbLoS_Sigmoid(theta1, c1, c2), 0, theta_D_min(ind_r));
    for ind_theta = 1 : len_theta
        if (theta(ind_theta) <= theta_D_min(ind_r)) && (theta(ind_theta) >= theta_D_max(ind_r))
            PDF_Closest_3D_Thr(ind_r, ind_theta) = 2 * pi * lambda_D * r(ind_r) ^ 2 * integral(@(theta1) sin(theta1) .* ProbLoS_Sigmoid(theta1, c1, c2), theta_D_max(ind_r), theta_D_min(ind_r)) * exp(-pi * lambda_D * beta_LoS(ind_r)) * r(ind_r) / (min(h_D_max, r(ind_r)) - h_D_min) * sin(theta(ind_theta));
        end
        beta_LoS_int1 = @(r1) arrayfun(@(r1) beta_LoS_int1_fun(r1, h_D_min, h_D_max, c1, c2), r1);
        fun01 = @(r1, theta1) exp(-pi * lambda_D * beta_LoS_int1(r1)) .* 2 .* pi .* lambda_D .* r1 .^ 2 .* sin(theta1) .* ProbLoS_Sigmoid(theta1, c1, c2) .* r1 .* (cos(min(theta(ind_theta), acos(min(h_D_max ./ r1, 1)))) - cos(min(theta(ind_theta), acos(h_D_min ./ r1)))) ./ (min(h_D_max, r1) - h_D_min);
        fun1 = @(r1, theta1) arrayfun(@(r1, theta1) fun01(r1, theta1), r1, theta1);
        CDF_Closest_3D_Thr(ind_r, ind_theta) = integral2(fun1, h_D_min, r(ind_r), @(r1) acos(min(h_D_max ./ r1, 1)), @(r1) acos(h_D_min ./ r1));
    end
    toc
end
% % surf(repmat(r, length(theta), 1), repmat(theta.', 1, length(r)), PDF_Closest_3D_Thr.')
% % hold off

function I = beta_LoS_int1_fun(r1, h_D_min, h_D_max, c1, c2)
g1 = @(theta1) (min(h_D_max ^ 3, r1 .^ 3 .* cos(theta1) .^ 3) - h_D_min ^ 3) .* sin(theta1) ./ cos(theta1) .^ 3 .* ProbLoS_Sigmoid(theta1, c1, c2);
I = 2 / 3 * integral(g1, 0, acos(h_D_min ./ r1));
end