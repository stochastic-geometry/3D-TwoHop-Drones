%% Parameters
lambda_D = 1e-7;
h_D_min = 50;
h_D_max = 300;
alpha_LoS = 2.5;
alpha_NLoS = 3;
Environment = 'HighriseUrban'; % Choose between 'Suburban', 'Urban', 'DenseUrban', and 'HighriseUrban'
[c1, c2, eta_LoS, eta_NLoS] = Compute_Param_LoS(Environment);

%% Simulation
x_D_min = -1e4;
x_D_max = 1e4;
y_D_min = -1e4;
y_D_max = 1e4;
Num_D_Initial = lambda_D * (x_D_max - x_D_min) * (y_D_max - y_D_min) * (h_D_max - h_D_min);
Realizations = 1e4;
A_N_vec = zeros(Realizations, 1);
tic
parfor i = 1 : Realizations
    Num_D = poissrnd(Num_D_Initial);
    Pos_D_x = unifrnd(x_D_min, x_D_max, [Num_D, 1]);
    Pos_D_y = unifrnd(y_D_min, y_D_max, [Num_D, 1]);
    Pos_D_z = unifrnd(h_D_min, h_D_max, [Num_D, 1]);
    Pos_D = [Pos_D_x, Pos_D_y, Pos_D_z];
    Pos_D_range = sqrt(sum(Pos_D .^ 2, 2));
    Pos_D_theta = acos(Pos_D_z ./ Pos_D_range);
    ProbLoS = ProbLoS_Sigmoid(Pos_D_theta, c1, c2);
    Pos_D_LoS_ind = rand(Num_D, 1) < ProbLoS;%0.5;
    Pos_D_NLoS_ind = ~Pos_D_LoS_ind;
    Pos_D_range_LoS = Pos_D_range(Pos_D_LoS_ind, :);
    Pos_D_range_NLoS = Pos_D_range(Pos_D_NLoS_ind, :);
    r_tilde_D_LoS = min(Pos_D_range_LoS);
    r_tilde_D_NLoS = min(Pos_D_range_NLoS);
    A_N_vec(i) = r_tilde_D_NLoS ^ (-alpha_NLoS) * eta_NLoS ^ -1 >= r_tilde_D_LoS ^ (-alpha_LoS) * eta_LoS ^ -1;
end
A_N_Sim = mean(A_N_vec);
A_L_Sim = 1 - A_N_Sim;
toc

%% Theory
r0 = (eta_NLoS / eta_LoS) ^ (1 / alpha_LoS) * h_D_min ^ (alpha_NLoS / alpha_LoS);
beta_LoS_int1 = @(r1) arrayfun(@(r1) beta_LoS_int1_fun(r1, h_D_min, h_D_max, c1, c2), r1);
beta_NLoS_int1 = @(r1) arrayfun(@(r1) beta_NLoS_int1_fun(r1, h_D_min, h_D_max, c1, c2), r1);
fun01 = @(r1, theta1) exp(-pi * lambda_D * (beta_LoS_int1(r1) + beta_NLoS_int1((eta_LoS / eta_NLoS) ^ (1 / alpha_NLoS) .* r1 .^ (alpha_LoS / alpha_NLoS)))) .* 2 .* pi .* lambda_D .* r1 .^ 2 .* sin(theta1) .* ProbLoS_Sigmoid(theta1, c1, c2);
fun02 = @(r1, theta1) exp(-pi * lambda_D * (beta_NLoS_int1(r1) + beta_LoS_int1((eta_NLoS / eta_LoS) ^ (1 / alpha_LoS) .* r1 .^ (alpha_NLoS / alpha_LoS)))) .* 2 .* pi .* lambda_D .* r1 .^ 2 .* sin(theta1) .* (1 - ProbLoS_Sigmoid(theta1, c1, c2));
fun1 = @(r1, theta1) arrayfun(@(r1, theta1) fun01(r1, theta1), r1, theta1);
fun2 = @(r1, theta1) arrayfun(@(r1, theta1) fun02(r1, theta1), r1, theta1);
A_L_Thr = integral2(fun1, r0, inf, @(r1) acos(min(h_D_max ./ r1, 1)), @(r1) acos(h_D_min ./ r1)) + 1 - exp(-pi * lambda_D * beta_LoS_int1_fun(r0, h_D_min, h_D_max, c1, c2));
A_N_Thr = integral2(fun2, h_D_min, inf, @(r1) acos(min(h_D_max ./ r1, 1)), @(r1) acos(h_D_min ./ r1));
% % p_N = 1 - 1e-6;
% % A_Np_Thr = p_N * integral(@(r1) 2 .* pi .* lambda_D .* r1 .^ 2 .* (min(h_D_max ./ r1, 1) - h_D_min ./ r1) .* exp(-pi * lambda_D * (...
% %     p_N * (((2 / 3 * r1 .^ 3 - h_D_min .* r1 .^ 2 + h_D_min .^ 3 / 3) .* (r1 <= h_D_max)) + (((h_D_max - h_D_min ^ 3 / (3 * h_D_max ^ 2)) * r1 .^ 2 - h_D_max .^ 3 / 3 - h_D_min .* r1 .^ 2 + h_D_min .^ 3 / 3) .* (r1 > h_D_max))) +...
% %     (1 - p_N) * (((2 / 3 * ((eta_N / eta_L) ^ (1 / alpha_L) .* r1 .^ (alpha_N / alpha_L)) .^ 3 - h_D_min .* ((eta_N / eta_L) ^ (1 / alpha_L) .* r1 .^ (alpha_N / alpha_L)) .^ 2 + h_D_min .^ 3 / 3) .* (((eta_N / eta_L) ^ (1 / alpha_L) .* r1 .^ (alpha_N / alpha_L)) <= h_D_max)) + (((h_D_max - h_D_min ^ 3 / (3 * h_D_max ^ 2)) * ((eta_N / eta_L) ^ (1 / alpha_L) .* r1 .^ (alpha_N / alpha_L)) .^ 2 - h_D_max .^ 3 / 3 - h_D_min .* ((eta_N / eta_L) ^ (1 / alpha_L) .* r1 .^ (alpha_N / alpha_L)) .^ 2 + h_D_min .^ 3 / 3) .* (((eta_N / eta_L) ^ (1 / alpha_L) .* r1 .^ (alpha_N / alpha_L)) > h_D_max)))...
% %     )), h_D_min, inf);
% % A_Lp_Thr = 1 - A_Np_Thr;

function I = beta_LoS_int1_fun(r1, h_D_min, h_D_max, c1, c2)
g1 = @(theta1) (min(h_D_max ^ 3, r1 .^ 3 .* cos(theta1) .^ 3) - h_D_min ^ 3) .* sin(theta1) ./ cos(theta1) .^ 3 .* ProbLoS_Sigmoid(theta1, c1, c2);
I = 2 / 3 * integral(g1, 0, acos(h_D_min ./ r1));
end
function I = beta_NLoS_int1_fun(r1, h_D_min, h_D_max, c1, c2)
g1 = @(theta1) (min(h_D_max ^ 3, r1 .^ 3 .* cos(theta1) .^ 3) - h_D_min ^ 3) .* sin(theta1) ./ cos(theta1) .^ 3 .* (1 - ProbLoS_Sigmoid(theta1, c1, c2));
I = 2 / 3 * integral(g1, 0, acos(h_D_min ./ r1));
end