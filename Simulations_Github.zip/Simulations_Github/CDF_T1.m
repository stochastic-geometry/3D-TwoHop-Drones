%% Parameters
a = 3;
b = 3;
I = 2;
m = 2;
N = 1e5;
X_Rayl = exprnd(1, [N, 1]);
Y_Rayl = exprnd(1, [N, 1]);
T1_Rayl = a * X_Rayl ./ (b * Y_Rayl + I);
X_Naka = gamrnd(m, 1 / m, [N, 1]);
Y_Naka = gamrnd(m, 1 / m, [N, 1]);
T1_Naka = a * X_Naka ./ (b * Y_Naka + I);

%% Analysis
tau = 0 : 0.01 : ceil(max(T1_Naka) * 100) / 100;
len_tau = length(tau);
F_T1_Rayl_Sim = zeros(length(tau), 1);
F_T1_Rayl_Thr = zeros(length(tau), 1);
F_T1_Naka_Sim = zeros(length(tau), 1);
F_T1_Naka_Thr = zeros(length(tau), 1);
for ind_tau = 1 : len_tau
    F_T1_Rayl_Sim(ind_tau) = sum(T1_Rayl <= tau(ind_tau)) / N;
    F_T1_Rayl_Thr(ind_tau) = 1 - a / (a + b * tau(ind_tau)) * exp(-tau(ind_tau) / a * I);
    F_T1_Naka_Sim(ind_tau) = sum(T1_Naka <= tau(ind_tau)) / N;
    A = 0;
    for i = 0 : m - 1
        for k = 0 : i
            A = A + nchoosek(k + m - 1, k) / factorial(i - k) * (a ^ m * (b * tau(ind_tau)) ^ k) / (a + b * tau(ind_tau)) ^ (m + k) * ((m * tau(ind_tau)) / a * I) ^ (i - k) * exp(-(m * tau(ind_tau)) / a * I);
        end
    end
    F_T1_Naka_Thr(ind_tau) = 1 - A;
end

%% Plots
figure(401)
hold on
grid on
box on
plot(tau, F_T1_Rayl_Sim, 'k', 'LineWidth' , 2)
plot(tau, F_T1_Rayl_Thr, 'r', 'LineWidth' , 2, 'LineStyle', '--')
plot(tau, F_T1_Naka_Sim, 'b', 'LineWidth' , 2)
plot(tau, F_T1_Naka_Thr, 'g', 'LineWidth' , 2, 'LineStyle', '--')
xlabel('$\tau$', 'Interpreter', 'latex', 'FontSize', 12)
ylabel('CDF of $T_1$', 'Interpreter', 'latex', 'FontSize', 12)
legend({'Rayleigh Fading, Simulation', 'Rayleigh Fading, Theory', 'Nakagami Fading, Simulation', 'Nakagami Fading, Theory'}, 'Interpreter', 'latex', 'FontSize', 12, 'Location', 'southeast')
hold off
